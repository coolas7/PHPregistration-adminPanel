Admino prisijungimas: admin slaptazodis: admin
U�duotis pilnai padaryta, viskas veikia.

U�duotis buvo:
Du vartotoju lygiai:

-adminas
-vartotojas

Teises:
adminas:

-sukurti u�duoti
-priskirti u�duoti
-redaguoti u�duoti
-i�trinti u�duoti

vartotojas:
-per�iureti jam priskirtas u�duotis
-pa�ymeti, jog u�duotis ivykdyta
